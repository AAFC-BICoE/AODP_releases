#! /bin/usr/perl

package Output_Cleanup;
use List::MoreUtils qw/uniq/;
use File::Find;
use File::Path;
use File::Basename;
use FindBin;
use File::Copy;
use threads::shared;
use Thread::Queue;
use Fcntl qw(:flock);
use POSIX qw(:sys_wait_h);
$| = 1;

use warnings;
use strict;

# Version 1.01

# Authors: Kaisheng (Kevin) Chen, Chuyang (Charles) Qi, Wen Chen* (wen.chen@agr.gc.ca)

# DOI: 10.5281/zenodo.10762

# License: MIT License (please refer to LICENSE.txt)

# Copyright (c) 2014 Government of Canada

sub combine_output {
	#This subroutine is run near the end of the program to produce 5 files
	#It will create the files for len25, and combine a fasta file for oligos of all lengths.
	#The outgroup will then be excluded.
	#This subroutine  will work in the "Output" folder
	#combines and sorts the file, and deletes the outgroup sequences from lenth25 only

	#if ($main::oligo_length_min > 25 || $main::oligo_length_max < 25){
	#	print "WARNING: Oligo length 25 is not in specified oligo range.\n";
	#}
	print "Preparing final outputs";
	
	#Gets the name of sequences with len25, cuts - and sorts into a list.
	#The outgroups will be taken out depending on this file
	if ($main::output_len25 == 1){
		open (TOS,"sigoli_$main::s_filename.strings.len25.txt.oligo.specific.withLonghomo.tab") or die;
		open (NLN,">node.len25")or die;
		my @nodelen25; #array used for sort and uniq 
		while (<TOS>){ #tranverses the file line by line
			my @splitter = split (/-/); #splits up by - to only get the name
			push (@nodelen25,"$splitter[0]\n"); #push the name onto the array
		}

		print ".";
		#sorts and uniq the array
		@nodelen25 = uniq @nodelen25;
		@nodelen25 = sort @nodelen25;
		#print out to new file
		print NLN @nodelen25;
		close NLN;
		close TOS;

		#goes through each file and outputs into extra nodes
		open (EXTRA,">extra.nodes");
		open (GRE,"node.len25") or die;
		my @togrep = <GRE>;

		#gets any extra nodes in all lens and gathers them together
		#also greps out any lines that belong to the outgroup 
		for (my $j = $main::oligo_length_min;$j<=$main::oligo_length_max;$j++){
			open (OFP,"sigoli_$main::s_filename.strings.len$j.txt.oligo.specific.withLonghomo.tab") or die; 
			my @ofpfile = <OFP>;
			foreach my $b (@togrep){ #Checks every node in file
				chomp $b;
				@ofpfile = grep !/$b/, @ofpfile; # takes the lines that contain NO outgroups
			}
			print EXTRA @ofpfile;
		}
		close EXTRA;
		close GRE;
		close OFP;
	}
	chdir ("..");

	#removes some uneeded files
	unlink ("Node1.id") or warn;
	unlink ("Nodes.list") or warn;

	#removes nodal files

	#outdata is created to place the final files
	mkdir ("Output");
	chdir ("Output");

	#Moves some files into this folder
	move ("../$main::s_tree.node.list","$main::s_tree.node.list") or warn;
	move ("../$main::s_tree.nwk","$main::s_tree.nwk") or warn;
	#Moves the notaln and excluded too
	move ("../$main::s_filename.notaln.fasta","$main::s_filename.notaln.fasta") or warn;
	move ("../excluded.fasta","excluded.fasta") or warn;

	#Creates outgroup patterns, which is a list of sequence names to be excluded from the lenall files.
	open (MYOUT,"../../../$main::outgroup") or die "Can't find outgroup";
	open (NODES,"../$main::s_outgroup.nodes") or die "Outgroup nodes can't find";
	open (OALL,">$main::s_outgroup.all");

	#if -i was set, opens the iso files
	my @isoarray;
	my $iso_expr;
	if ($main::isolation == 1){
		open (MYISO,"../../../$main::isofile");
		@isoarray = <MYISO>;
		chomp @isoarray;
		#also pushes "node" onto the array
		push(@isoarray,"Node"); 
		$iso_expr = join ("|",@isoarray);
	}

	#Goes through outgroup and adds - to the end line
	while (<MYOUT>){
		chomp $_;
		print OALL "$_\n";
	}

	print OALL <NODES>; #Concatenates onto the new file
	#Close filehandles
	close MYOUT;
	close NODES;
	close OALL;

	#opens the OFP files of len25 for grepping
	if ($main::output_len25 == 1){
		open (FH,"../sigoli.$main::s_filename/sigoli_$main::s_filename.strings.len25.txt.oligo.specific.withLonghomo.tab") or warn;

		open (FH2, "../sigoli.$main::s_filename/extra.nodes") or warn;
	}
	open (GR,"$main::s_outgroup.all"); #outgroup that needs to be grepped out 

	my @grepgroup = <GR>; #reads the grep file into memeory
	chomp @grepgroup;
	#makes the grep expr
	my $grep_expr = join ("|",@grepgroup);
	if ($main::output_len25 == 1){
		open (NF,">sigoli.$main::s_filename.len25andother.tab.exOGtest"); #new file sorted and greped
		print ".";


		#concatenate the 2 files
		print NF <FH>;
		print NF <FH2>;
		close NF;


		open (RF,"sigoli.$main::s_filename.len25andother.tab.exOGtest"); #reads the concatenated file
		#greps out the outgroup from len25 file aswell
		my @arr = sort <RF>;
		close RF;
		@arr = grep !/$grep_expr/,@arr;
		#also remove sequences that are not ones defined in isolate
		if ($main::isolation == 1){
			@arr = grep /$iso_expr/,@arr;
		}
		print ".";

		open (NF2,">$main::s_filename.len25.tab");
		#merge into tempsort prints the grepped file 
		print NF2 @arr;
		unlink ("sigoli.$main::s_filename.len25andother.tab.exOGtest") or warn ("Could not remove OFPtest!\n");
		#close all filehandles
		close FH;
		close FH2;
		close GR;
		close NF2; 
		#///
		#combines all the len files and sorts.
	}
	my @all;
	for (my $j = $main::oligo_length_min;$j <= $main::oligo_length_max;$j++){
		open (AF,"../sigoli.$main::s_filename/sigoli_$main::s_filename.strings.len$j.txt.oligo.specific.withLonghomo.tab") or warn;
		print ".";
		push (@all, <AF>); #combines all the files and pushes onto the array
	}
	#greps the array
	@all = grep !/$grep_expr/,@all;
	#also remove sequences that are not ones defined in isolate
	if ($main::isolation == 1){
		@all = grep /$iso_expr/,@all;
	}
	#sorts and prints to the file
	open (ALF,">$main::s_filename.lenall.tab");
	@all = sort @all;
	print ALF @all;
	close AF;
	close ALF;

	#use this lenall in xref to make it more specific.
	#delete this file afterwards, convert new fastas.
	&fasta_to_OFP("$main::s_filename.lenall.tab");
	if ($main::output_len25 == 1){
		&fasta_to_OFP("$main::s_filename.len25.tab");
	}

	&fasta_to_gff3("$main::s_filename.lenall.fasta","$FindBin::Bin/outdata/$main::folder/Output/$main::s_filename.notaln.fasta");
	if ($main::output_len25 == 1){
		&fasta_to_gff3("$main::s_filename.len25.fasta","$FindBin::Bin/outdata/$main::folder/Output/$main::s_filename.notaln.fasta");
	}

	if ($main::unite == 1){
		print ("Cross validating with the database:\n");
		#call xrefs
		Xref($main::unite_pattern,"$main::s_filename.lenall.fasta","$main::s_filename.lenall.tab");
		if ($main::output_len25 == 1){
			Xref($main::unite_pattern,"$main::s_filename.len25.fasta", "$main::s_filename.len25.tab");
		}
	}

	#Fasta file of length 25
	#this function outputs tab max4homo files based on the len25andother file
	#Sigoli_Func::OFP_multilen("$main::s_filename.len25andother");
	#(function is disabled for now)
	unlink ("../$main::s_outgroup.nodes")or warn;

}

my @taxbase;
my @ref_blast;
#% counts
my $total;
my $current : shared;
$current = 0;

sub Xref{
	my $pattern = shift;
	my $oligo_file = shift;
	my $oligo_tab_file=shift;
	my $s_oligo = basename ($oligo_file,".fasta");
	my $pcount=0;
	my $len = shift;

	my $reffasta=$main::ref_fasta;
	my $reftax=$main::ref_tax;

	my $ref_fasta = "$FindBin::Bin/Reference/$reffasta";
	my $ref_tax = "$FindBin::Bin/Reference/$reftax";
        
        my $s_ref_fasta=basename($ref_fasta,".fasta");
	
        open (TAX,"$ref_tax")or die;
	@taxbase = <TAX>;
	close TAX;


	open (BAD,">notspecific.seq")or die;
	mkdir ("tmp");

	flock (BAD,LOCK_EX);
	
	#making the blast database if it doesn't already exist
	unless(-e "$ref_fasta.nhr"){	
        	if( system("makeblastdb -in $ref_fasta -dbtype 'nucl'")!=0){
                	die "Error executing system command\n";
       		}
	}
        
        #blasting the oligo against the reference database 
        #output is 25 column tabular output
        my $blast_str="Blasting the oligos against the $s_ref_fasta database";
	print "$blast_str\r";
	
	#use fork to show blast progress--------------------------
	defined(my $pid = fork) or die "Couldn't fork: $!";

	if (!$pid) { # Child
  		exec("blastn -query $oligo_file -db $ref_fasta -evalue 0.001 -task blastn -out $s_oligo.blastn.tab -word_size $main::oligo_length_min -dust no -outfmt '6 qseqid sseq sseqid qlen qstart qend mismatch gaps' -num_threads $main::thread") 
    		or die "Couldn't exec: $!";
	} else { # Parent
		my $counter=0;
		my $str;
  		while (! waitpid($pid, WNOHANG)) {
    			if($counter<3){
				$blast_str =~ s/^\s+|\s+$//g ;
				$blast_str.=".";
			}
			else{
				$counter=-1;
			        $blast_str="Blasting the oligos against the $s_ref_fasta database   ";
			}
			print "$blast_str\r";
			$counter++;
    			sleep 2;
  		}
  		print "\n";
	}

	#------------------------------------------------------------
	#gets the line count from blast output
	open (COUNTER,"$s_oligo.blastn.tab");
        while (<COUNTER>){}
        $total += $.;                        
	close COUNTER;
	                                        
	#read blast output into an array
	open (BLAST_OUTPUT,"$s_oligo.blastn.tab")or die;
        my @blast_output = <BLAST_OUTPUT>;
        close BLAST_OUTPUT;

	
	print "Processing blast output:\n";
		
	
	#get unique seqids from tabular blast and write to file
	my $cur_id;
	my @blast_split;
	my %seen;
	open(my $unique_seqs,">","tmp/unique.tmp") or die;
	foreach (@blast_output){
		@blast_split=split(/\t/,$_);
		$cur_id= $blast_split[0];
		unless($seen{$cur_id}){
			$seen {$cur_id} =1;
			print $unique_seqs "$cur_id\n";
		}
	}
	
	#write all oligos not in blast results to file
	open (NOT_IN_BLAST,">tmp/not_in_blast.tmp")or die;
	print NOT_IN_BLAST `grep -vFif "tmp/unique.tmp" $oligo_tab_file`;	



	#get a list of all hits with the same sequence id and write each list to @all_seqs
	my @seq;
	my @all_seqs;
        @blast_split =split(/\t/,$blast_output[0]);
        my $prev_id=$blast_split[0];
        $cur_id=undef;
	foreach(@blast_output){
		@blast_split =split(/\t/,$_);
		$cur_id=$blast_split[0];
		unless($cur_id eq $prev_id){
			push(@all_seqs,[@seq]);
			$prev_id=$cur_id;
			@seq=();	
		}			
		push(@seq, $_);
	}
	#read into hash
	my %oligo_hash;
	my $seqio = Bio::SeqIO->new(-file => "$oligo_file", -format => "fasta");
	while(my$seqobj = $seqio->next_seq) {
    		my $id  = $seqobj->display_id;    # there's your key
    		my $seq = $seqobj->seq;           # and there's your value
    		$oligo_hash{$id} = $seq;
	}
	my $hash_ref =\%oligo_hash;
	#do the work on each @seq using multiple threads
	my $queue = Thread::Queue->new(@all_seqs);
	my @threads;
	for my $i(1 .. $main::thread){ 
			push @threads, threads->new( sub {
				# Pull work from the queue, don't wait if its empty
				while( my $hits_ref = $queue->dequeue_nb ) {
					my @hits=@$hits_ref;
					&blastcheck($pattern,$hash_ref,@hits);
				}
			});
	} 

	$_ -> join for @threads;
	print "100.0%\r";
	
	close $unique_seqs;
	if($main::erase_blastresults==1){
		unlink("$s_oligo.blastn.tab");
	}		
	&combine_all("$s_oligo.superspecific.tab");
	
	close GOOD;
	close BAD;
	close NOT_IN_BLAST;
	
	rmtree("tmp") or warn;

}

sub blastcheck{
	#`````````````````````````````````````
	my $pattern=shift;
	my $hash_ref=shift;
	my %oligo_hash=%$hash_ref;
	my @tab_blast= @_;
	#getting sequence and id of currentline
	my @tab_split =split (/\t/,$tab_blast[0]);
        my $cur_id= $tab_split[0];
	my $cur_seq;

		
	#update progress
	$current+=scalar @tab_blast;
	printf("%.1f%%\r",($current/$total)*100);

	open (GOOD,">tmp/$cur_id.tmp")or die;

	#set good to 0. If it is still 0 after checking all the possible blast matches then the sequence is specific. 
	my $good = 0;

	foreach(@tab_blast){
		#parsing blast result data
		my @fields = split (/\t/,$_);
		my $gi_num= $fields[2];
		my $query_len = $fields[3];
		my $seq_len=$fields[5]-$fields[4]+1;
		my $mismatches = $fields[6];
        	my $gaps =$fields[7];
		$cur_seq=$fields[1];
		#checking for perfect match (no gaps and mismatches for the ENTIRE sequence)		
		if (($seq_len==$query_len) && $mismatches==0 && $gaps==0){
			
			#there is a identifical match in blast, checking the taxonomy database...	
			chomp $gi_num;
			#got a name. Check the line in the taxon
			my @line = (grep/$gi_num/,@taxbase);
			#line[0] should always exist
			if ($line[0] !~ m/$pattern/){
				#One of the taxonomies don't match the specified. It's no good.
				$good = 1;
				chomp $line[0];
				#this prints the FIRST mismatch, not all!
				print BAD $cur_id,"\tReason:$line[0]\n$cur_seq\n";
				last;
			}
        	}
	}
        #sequence got through the tests. Print it in good
	if ($good == 0){
		 #get the full sequence from oligo file
		 $cur_seq=$oligo_hash{$cur_id};
		 #eliminate newlines
		 chomp $cur_seq;
       		 print GOOD $cur_id,"\t$cur_seq\n";
	}        
}
sub combine_all{
	my $name = shift;
	opendir (DIR,"tmp");
	open (ALL,">$name")or die;

	#write all sequences not in blast results
	open(NOT_IN_BLAST, "tmp/not_in_blast.tmp")or die;
	print ALL <NOT_IN_BLAST>;
	close NOT_IN_BLAST;
	#delete unnecessary files
	unlink ("tmp/not_in_blast.tmp");
        unlink("tmp/unique.tmp");
	#write all sequences that passes the cross validation
	while (readdir (DIR)){
		my $currfile = $_;
		open (CURR,"tmp/$currfile")or die;
		print ALL <CURR>;
		close CURR;
		#delete unnecessary files
		unlink ("tmp/$currfile");
	}
}


sub fasta_to_OFP{
	#simple subroutine that makes fasta files into OFP style format
	my $in_file = shift;
	my $s_file = basename ($in_file,".fasta",".tab","tab"); #takes out .fasta in input name
	open (IN,$in_file) or die;
	open (OUT,">$s_file.fasta")or die;
	while (<IN>){
		#converts the OFP format into fasta
		s/^/>/g; #replaces start line with >
		s/\t/\n/g; #replaces tabs with newline
		print OUT $_;
	}
	close IN;
	close OUT;
}

sub fasta_to_gff3{
	#subroutine that converts the fasta oligos to gff3 format.
	#seqid src type start end score strnad phase attr
	#the oligo name is separated by '-', the last of which contains the start and end
	#attr column will have ID 
	my $in_file = shift;
	my $orig_fasta = shift; #original input fasta to be put at end

	open (FASTAFILE,$in_file)or die;
	my $s_file = basename ($in_file,".fasta",".tab","tab"); #takes out .fasta in input name
	open (NEWFILE,">$s_file.gff")or die;
	my @fasta = <FASTAFILE>; #reads the fasta into memory as it will need to be placed later inside
	close FASTAFILE;

	print NEWFILE "##gff-version 3\n";

	my $count=0; #count to generate unique ids
	foreach (@fasta){
		#goes through the fasta, split the needed info
		my $line = $_;
		if ($line =~ m/>/){ #if line matches and ID
			#split the needed info
			$line =~ s/>//;#takes out the >
			my @fields = split(/\-/,$line);
			my $bounds = $fields[-1]; #start and end
			my $seqid = $fields[0];
			my $type = $fields[1];
			#the start and end fields need to be split into actual integers
			$bounds =~ s/\(//;
			$bounds =~ s/\)//;

			my @startend = split (/e/,$bounds);
			my $start = $startend[0];#this still has the s, so we need to take it out
			$start =~ s/s//;
			my $end = $startend[1];
			chomp $start;
			chomp $end;

			$count++;
			
			#values are more or less here, we can print the gff style			
			print NEWFILE "$seqid\t.\t$type\t$start\t$end\t.\t+\t.\tID=$seqid-$count;Name:";
		}else{
			print NEWFILE $line;
		}	
	}
	#print the original fasta file to the end
	print NEWFILE "##FASTA\n";
	open (ORIG,$orig_fasta);
	print NEWFILE <ORIG>;
	close NEWFILE;
}
1;
