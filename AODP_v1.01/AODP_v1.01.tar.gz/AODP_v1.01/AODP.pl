#!/usr/bin/perl -w
use strict;
use File::Copy;
use File::Basename;
use Cwd;
use Bio::SeqIO;
use List::MoreUtils qw/uniq/;
use File::Find;
use File::Path;
use FindBin;
use Getopt::Long;

#Modules
use lib "$FindBin::Bin/modules";
use File_Convert;
use Tree;
use Sigoli_Func;
use Output_Cleanup;

$| =1; #turns off buffer so prints go in the right order
# Program Name:  Automated Oligonucleotide Design Pipeline (AODP)
# Program Purpose: Facilitate the interpretation of NGS data at species or even lower taxonomic levels by utilizing signature oligos.
# Version 1.01

# authors: Kaisheng (Kevin) Chen, Chuyang (Charles) Qi, Wen Chen* (wen.chen@agr.gc.ca)

# license: wet-boew.github.io/wet-boew/License-en.html; # wet-boew.github.io/wet-boew/Licence-fr.html

# Needed to run this script:
#  -Perl ~3.8 or above (from Bioperl)
#  -Bioperl
#  -installed sigoli program
#  -proper modules in the folder (Tree.pm, File_Convert, Sigoli_Func)

# Script Description:
#  Takes one aligned fasta file, one .tre file, and an outgroup list file. The oligo maximum and minimum lengths need to be specified.
# Input must be in the indata directory
#  The program will output the resutls in indata/filename.date folder. It will set up folder enviornment needed for Sigoli to run.
#  Tree_and_nodes (Sigoli requirement) and a backup will be created in indata/filename.date. These are required for sigoli to run. The tree_and_nodes folder can be deleted. 
#  The sigoli for each lengths will have output in the sigoli_folder.
#  The final sigoli output for len25 and all lengths will be in the modified data folder 

#Edit the oligo min and max and thread counts.
#===============================================================================================================================================================================================

our $thread= 4;                                                                          #how many threads to use. (Generally, for a system 1 core = 1 thread. Putting more threads than your CPU core count results in no preformance gain)

our $oligo_length_min = 25;                                                             #minimum length of the oligo to be designed, e.g 10, 18, 25 etc, 

our $oligo_length_max = 28;                                                                #maximum length of the oligo to be designed, e.g. 30, 35 etc.

my $erase_tree = 1;  #determines whether the tree_and_nodes folder should be removed after the program finishes. 0 = no, 1 = yes

my $erase_sigdata = 1; #determines whether to remove sigoli's vanilla outputs, which is largely not needed after final output is generated. 0= no, 1= yes

our $erase_blastresults =1; #determines whether to remove blast results after the cross validation is finished. 0= no, 1= yes

my $erase_OFP = 0;

our $output_len25 = 0; #determines whether or not to kill basis length stuff

#END-OF-EDITS=============================================================================================================================================================================================================================================================
#Do not make any changes below unless you are reasonably comfortable with Perl

my $filename="";                                                                                                         #input(fasta) file (ALIGNED)
my $in_tree="";                                                                                      #user's tree input file. This should end in .tre
our $s_tree;
our  $outgroup="";          #outgroup list file. This should end in .outgroup
our $isolation = 0; #-i option. User will need to include a file containing patterns to isolate from the data.
#0 = no, 1 = yes

our $isofile="";#-i option file. Initialized to blank in case nothing was found or -i is not being used.

our $nameswitch = 0; #names option. User will have to input a .names file.

our $namesfile="";

my $OFP_link =0;

our $unite = 0; #cross referencing with unite database option. 
our $unite_pattern="meow";

#file specifics. They are set in the prep subroutine
my $full_filename;                                                                                                     #full file name e.g dog.txt
my $f_extension;                                                                                                   #input file's extension e.g txt
our $s_filename;                                                                                      #small filename without the extension eg. dog
our $s_outgroup;

my $indir="indata";
my $config_path= "config";
our $folder;#folder that stores the output

#files from the reference sets
our $ref_fasta;
our $ref_tax;

my $start_time = time(); #starts the timer for the program

&config;

&usage;                                                                                    #Subroutine which checks that all the inputs are correct and fishes out the indata
&prep;                                                       #Subroutine which creates the necessary folder format (indata, unique dated directory)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#PART1: Prepares files for sigoli.

#this subroutine de-aligns the original alignment file and outputs $filename.notaln.fasta
#INPUT: ORIGINAL-ALIGNED-FASTA
#OUTPUT FILENAME.NOALN.FASTA in CURRENT DIRECTORY
File_Convert::rewrite_fasta("../../$filename");

#This module generates the .nwk file from the .tre file. Output messages are surpressed with dev null.
#This module uses List::Compare
#INPUT: ORIGINAL-TREE ORIGINAL-OUTPUT
#OUTPUT TREEFILENAME.NWK, TREEFILENAME.NWK.NODELIST IN MAIN DIRECTORY (CHANGE THIS, MESSY)
#NODE LIST IN CURRENT DIRECTORY

File_Convert::add_treenodes("../../$in_tree", " ../../$outgroup", $isolation,"../../$isofile");

#moves the made files out of indata and into the output directory
move ("../../$in_tree.nwk","$s_tree.nwk") or die;
move ("../../$in_tree.nwk.node.list","$s_tree.node.list") or die;
if ($nameswitch == 1){
	move ("../../$in_tree.names.nodelist","$s_tree.names.nodelist") or die;
}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#PART2: Works with tree_and_nodes folder, which will contain the folders sigoli works on

#Creates tree_and_nodes folder and Nodes.list file
Tree::treeprep("$s_tree.nwk");
chdir ("tree_and_nodes");  

# This subroutine creates the folder system that sigoli uses. It needs the node list and .nwk tree file. 
#INPUT: IN_TREE.NWK NODES.LIST
#OUTPUT: Folder for each node in tree_and_nodes directory, with corresponding leaves in the folders.
Tree::createnodes("../$s_tree.nwk","../Nodes.list");

#Preform cleanup and backup at the end of step  
#backups tree_and_nodes 

move ("Node1.id","../Node1.id");                                                                     #moves the ID outside or Sigoli will complain
 
chdir ("..");                                                        #changes directories outside of tree in nodes as the folder needs to be searched

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#PART2.5: Tree and Node tranversing and modification for sigoli

#tranverses the tree_and_nodes directory to find seqIDs and creates folders for each sequence found
#every seqid found in tree and nodes will be worked on
#each file thereby created will only contain one sequence
#each node folder will contain any node that it is a parent of, but it only goes one level. 
#for example,the tree Node1 - Node2 - Node3 will create 3 folders.  
Tree::tranverse($s_filename,$thread);

print ("\n"); 

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#PART3: Sigoli calls 

chdir ("tree_and_nodes");                                                                                #moves back into tree and nodes for sigoli.

#my $start_time = time(); #starts the timer for the program

#this sub uses the program sigoli to search through the tree and nodes 
#sigoli will output sigoli_$filename.strings.lenX.txt files depending on oligo max/min specified
#The thread count, oligo max/mins are used as input, as well as the original unaligned fasta file.
#This must be run inside the tree and nodes folder with the above input.
#OUTPUT: sigoli.filename.stringslenX.txt, where x depends on oligio min/max
Sigoli_Func::start_sigoli($thread, $oligo_length_min, $oligo_length_max, "../../../$filename", "." );
print ("\n"); 

# creates a sigoli folder to store the useful outputs that sigoli produces.
chdir ("..");
mkdir ("sigoli.$s_filename");


#moves all sigoli files to new directory
my @oldfiles = glob "tree_and_nodes/sigoli_*";
my $newdir = "sigoli.$s_filename";
foreach my $of (@oldfiles){ #puts all newly created files into new directory
 move ($of,$newdir); 
}
#calculate total run time
#my $end_time = time ();
#my $run_time = $end_time - $start_time;
#
# The loop checks the specificity of every oligo length output by sigoli
#It finds the match of the designed oligo in the converted fasta file and gives the total number of matches.
#Also places the non-specific oligos and specific oligos into different files.
#In the same step, the specific files are convereted into OFP format
Sigoli_Func::specific_OFP_gen($oligo_length_min,$oligo_length_max,$s_filename,$thread);

print ("\n");
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#PART4: Len25 and final outputs
#There will be tens of thousands of oligos designed by Sigoli. Len25 oligos are used as a basis to select oligos for the node.
chdir ("sigoli.$s_filename");

#my $start_time = time(); #starts the timer for the program

Output_Cleanup::combine_output; #various procedures that interpet sigoli's output

#calculate total run time
my $end_time = time ();
my $run_time = $end_time - $start_time;
 
#delete tree_and_nodes if set
if ($erase_tree == 1){
	chdir ("..");
	rmtree ("$FindBin::Bin/outdata/$folder/tree_and_nodes") or warn "Could not remove tree and nodes!\n";
}

#delete the sigoli folder if set
if ($erase_sigdata == 1){
	rmtree("$FindBin::Bin/outdata/$folder/sigoli.$s_filename") or warn;	
}
 
print "\nFinished running. Took a total of $run_time seconds.\n";

print ("\n\n\n===========END==========================================================================\n\n");

####END OF MAIN#####################################################################################################################################
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
####################################################################################################################################################

sub config{
	#this sub reads from the configuration file and checks if everything is defined.
	open (CONF,"$config_path") or die;
	while (<CONF>){
		my $line = $_;
		chomp $line;
		my @split;
		if ($line =~ m/^THREAD_COUNT/){
			@split = split(/=/,$line);
			$thread = $split[1];
		}elsif($line =~ m/^OLIGO_MIN/){
			@split = split(/=/,$line);
			$oligo_length_min = $split[1];
		}elsif($line =~ m/^OLIGO_MAX/){
			@split = split(/=/,$line);
			$oligo_length_max = $split[1];
		}elsif($line =~m/^OUTPUT_LEN25/){
			@split = split(/=/,$line);
			$output_len25 = $split[1];
		}elsif($line =~m/^ERASE_TREE/){
			@split = split(/=/,$line);
			$erase_tree = $split[1];
		}elsif($line =~m/^ERASE_SIGDATA/){
			@split = split(/=/,$line);
			$erase_sigdata = $split[1];
		}elsif($line =~m/^ERASE_BLASTRESULTS/){
			@split = split(/=/,$line);
			$erase_blastresults =$split[1];
		}elsif($line =~ m/^REFERENCE_FASTA/){
			@split = split(/=/,$line);
			$ref_fasta = $split[1];
		}elsif($line =~ m/^REFERENCE_TAX/){
			@split = split(/=/,$line);
			$ref_tax = $split[1];
		}elsif($line =~m/^INPUT_FOLDER/){
			@split = split(/=/,$line);
			$indir = $split[1];
		}
	}
	
	#check if all the values are defined

	close CONF;
}

sub usage{
	#subroutine that provides usage information and checks input from the indata folder

# if ( @ARGV != 6){
#	print "Please provide: <INPUT_FASTA>(.fasta) <OLIGO_LENGTH_MIN>(int) <OLIGO_LENGTH_MAX>(int) <INPUT_TREE>(.tre) <OUTGROUP_LIST>(.outgroup)  <THREAD_NUMBER>(int)\n";
#	exit;
# }

	#assigns global variables to parameters provided
# $filename = $ARGV[0]; 
# $oligo_length_min=$ARGV[1]; 
# $oligo_length_max=$ARGV[2]; 
# $in_tree = $ARGV[3];
# $outgroup=$ARGV[4]; 
# $thread=$ARGV[5];

#Checks if the fasta file exists. 

	print ("\n===========RUNNING================================================================\n");
	print ("Using ",$thread, " threads and with Oligo minimum length of $oligo_length_min and maximum of $oligo_length_max :\n\n\n");

	#reads everything from the indata folder
	my @files = <$indir/*>;

	#AODP's options
	my $help;
	my $iso_opt;
	my $unite_opt;
	my $names_opt;
	my $config;

	GetOptions ("--help" => \$help,"-i" => \$iso_opt,"u=s" => \$unite_opt,"-n" => \$names_opt, "-c=s" => \$config)or die; 


 #checks for unite
 #this option can be used with the others
 if (defined $unite_opt){
	 $unite =1;
	 #get the pattern	 
	 $unite_pattern = $unite_opt;

	 #check files
	 if (! -e "$FindBin::Bin/Reference/$ref_fasta" || ! -e "$FindBin::Bin/Reference/$ref_tax"){
		 die "Error in Reference files. Please check the filenames.\n";
	 }

	 print ("Using crosschecking option with pattern $unite_pattern\n");
 }

 if(defined $help){ 
	 #outputs messages about how to use the program 
	 #calls the man
	 system ("perldoc AODP.pl");
	 exit
 }elsif (defined $iso_opt){
	 #isolate option is on. Program will only get the output from isolated patterns
	 $isolation = 1;
	 print ("Using -i option!\n");
 }elsif(defined $names_opt){
	 $nameswitch = 1;
	 print ("Using names option!\n");
 }elsif (grep(/-/,@ARGV)){
	 #check for random options (obsolete)
	 print ("Invalid option\n");
	 exit;
 }	
 
 if(defined $config){
	#reads in config file
 	$config_path = $config;
	#check for config file existence 
 	unless(-e "$config_path") {
 		die "The specified config file does not exist.\n";
 	}
}
 
 if($isolation == 0 && $nameswitch == 0 && scalar(@files) != 3){
	 #Make sure no hidden files are in this folder
	 #Outputs messages
	 print ("Invalid number of files in indata folder. Please only put desired dataset.\n"); 
	 print ("Delete all hidden files from indata folder.\n");
	 print ("There should be 3 files in the indata folder: the FASTA file, the tree file and the outgroup pattern.\n");
	 print ("Use the --help option for more usage information.\n");
	 exit;
 }elsif ($isolation == 1 && scalar(@files) != 4){
	 #checks if isolation was set
	 print ("-i option was set. In addition to standard 3 input files, an additional 'iso' file is needed in the indata folder.\n");
	 exit;
 }elsif($nameswitch == 1 && scalar(@files) != 4){
	 print ("-n option was set. In addition to the standard 3 input files, an additional 'names' file is required.");
	 exit;
 }
 else{
	 #finds all files in the indata folder. Calls autoinput for each file found
	 find ({wanted => sub {&autoinput;}, no_chdir => 1},$indir);
 }

#check if the files actually exist
 if (! -e $filename){
	 die "Fasta file does not exist in specified directory.";
 }
#checks oligo length min/max, and that the max is greater or equal to the min.
 elsif ($oligo_length_min < 0 || $oligo_length_max < 0 || $oligo_length_max < $oligo_length_min){
	 die "Invalid Oligo lengths. Either they are negative or the max is less than min.";
 }
#checks pre-defined outgroup pattern file exists
 if (! -e $outgroup){
	 die ("Outgroup file does not exist");
 }elsif (! -e $in_tree){ #checks that the tree exists
	 die ("Tree file does not exist");
 }

 if ($isolation == 1 && $isofile eq ""){
	 print ("ISO file was not found.\n");
	 exit;
 }

 if ($nameswitch == 1 && $namesfile eq ""){
	 print ("Names file was not found.\n");
	 exit;
 }
#checks that the thread is not negative
 elsif ($thread < 1){
	 die "Thread count can not be less than 1.";
 }
#checks that sigoli is installed
 my @sigolitest = `sigoli --help`; #dry run of sigoli to see if program is installed
 if (!$sigolitest[1]){ #sigoli doesn't exist - exit
	 print ("Sigoli is not installed!");
	 #Call makefile from sigoli package, run sigoli.exe in folder
	 exit;
 }else {
	 #sigoli is installed!
	 print ("Sigoli was found to be installed.\n");
 }
 print ("Input paramaters are valid.\n");
 print ("- - - - - - - - - - \n");
}

#Automatically gets needed files from indata folder
sub autoinput{
  my $found = $_;
  if ($found =~ m/fasta/){
    $filename = $found;
    print ("Using $found\n");
  }elsif ($found =~ m/tre/){
    $in_tree = $found;  
    print ("Using $found\n");
	}elsif ($found =~ m/outgroup/){
		$outgroup = $found;
		print ("Using $found\n");
	}
	#options
	if ($isolation == 1 && $found =~ m/iso/){
		$isofile = $found;
	  print ("Isolation file is $found\n");	
	}
	if ($nameswitch == 1 && $found =~m/names/){
		$namesfile = $found;
		print ("Names file is $found\n");
	}
}

##########################################################################################################
sub prep{ 
 #subroutine that sets up some variables and outdata folders

	#Checks if the outdata folder exists.
	if (! -e "outdata"){
		#Indata doesn't exist, create indata
		mkdir ("outdata");
	}
	chdir ("outdata"); #changes directories into the "outdata" directory. This has been made if not present.

	$full_filename = basename ($filename);                       #this removes any paths in front of the file.
	($f_extension = $full_filename) =~ s/^[^.]+\.//;              #sets the extension into the global variable
	($s_filename = $full_filename) =~ s/\.[^.]+$//;          #sets the small filename into the global variable
	$s_outgroup = basename ($outgroup);											#removes path of outgroup file
	$s_tree = basename ($in_tree); 														#removes path of tree


	my $DATE=POSIX::strftime("%Y_%B%d_%H_%M",localtime());                  #gets the date into the format YEAR/MONTH/HOUR/MINUTE
	#creates a directory in the format filename.index_and_sigoli.currentdate

	$folder = "$s_filename.$DATE"; 
	chomp $folder;        #chomp line is needed to remove uneeded lines, otherwise chdir will not be functional
	#Checks if there is already a folder with the name. 
	#In that case, the program has been run very recently, and a new folder does not need to be made.
	if (! -e $folder){
		mkdir ($folder) or warn ("Could not make $folder\n"); 
	}else{
		rmtree ($folder) or die ("Could not remove $folder from previous run\n");
		mkdir ($folder);
	}
	chdir ($folder);                      #moves into created folder

}

__END__

=head1 NAME 

=over 12

=item B<A>utomated B<O>ligonucleotide B<D>esgin B<P>ipeline (AODP)

=back

=head1 SYNOPSIS

perl AODP.pl [-i] [-n] [-u PATTERN] [-c config] [--help]

=head1 DESCRIPTION

The Automated Oligoneucleotide Design Pipeline extracts signature oligoneucliotides of specified lengths primarily using the progrom SigOli (Signature Oligo, Manuel Zahariev). Using these outputs from taxon groups of interest, they can be used to identify species with great accuracy.

To run, taget fasta file, tree, and outgroup list needs to be placed in the indata folder. The script will automatically get the files from the folder. Make sure only the desired dataset is in the indata. Once the files have been placed, simply run the script using "perl AODP.pl" or "./AODP.pl". The default oligo lengths to search for are 25-28, using 24 threads. The user will need to set these values in the script to their preference.


=head1 OUTPUTS

A dated folder with the dataset name will be generated in the "outdata" folder. All output will be placed in this folder for the particular run. 

In this folder, a concrete not aligned version of the input fasta will be found. This contains the sequences with alignment and problematic sequences removed. These problematic sequences are placed in uncalculated.fasta in the same directory.

A folder with the sigoli folder can also be found. This folder contains the vanilla output from the SigOli program and the specific/OFP files for each oligo length. This folder is useful if output from a specific length is required, otherwise the next folder is useful.

The generated newick tree and it's related outputs(nodes list, outgroup nodes) are generated in the same directory.The IDs of all the sequences are placed in Node1.id, and a list of all the node counts are placed in Nodes.list. The node list is very useful for a concrete list of all the sequences that exist inside of a node.

The final folder is the "Modified Data" folder, and it contains the main output for the run. Output of length 25 will be captured here for the purpose of having a smaller subset of the data to put in the OFP pipeline. Additionally, the combined oligios of all lengths will be created here, containing everthing that was found.

The generated newick tree and it's related outputs(nodes list, outgroup nodes) are generated in the same directory.The IDs of all the sequences are placed in Node1.id, and a list of all the node counts are placed in Nodes.list. The node list is very useful for a concrete list of all the sequences that exist inside of a node.

If the -u option is specified, the superspecific versions of the output will also be created. 


=head1 OPTIONS

Input options as parameters.

=over 12
	
=item B<--help> 

Ouputs program information and usage instructions. Further instructions are outlined in this document and the manual. 
	
=item B<-i>	

"Isolate" option. Requires an additional file in the outdata folder with ".iso" as the extension. The sequence names outlined in the file will the isolated in the final output, as well as the nodes that contain only those sequences. 

=item B<-u>

"UNITE" cross-referencing option. The generated oligos will further be checked for specificity within the UNITEdatabase. The user will need to define a pattern that the the sequence's taxonomy needs to match to.
B<WARNING:> This option takes a significant amount of time. 

=item B<-o>

"OFP integration" option. Intended for use with outputs from the Oligo-Fishing Pipeline (OFP). The AODP program will try to match the OFP output sequences with the given reference tree using MAFFT and report the relative area. 

=item B<-n>

"Name" file switch. Allows the AODP to utilize name files. Simply place the names file in the indata folder along with the standard input. Make sure that the target fasta and tree are already unique. The names file will be integrated into the node list.

=item B<-c>

Specify the path of the config file used for additional options such as number of threads, reference database files, etc.

=back

=head1 BUGS

Sigoli is, as of right now, not optimized for sequences with too many ambiguous bases. The program will remove sequences with over 5 ambiguous bases, and note these sequences in uncalculated.txt

=cut


